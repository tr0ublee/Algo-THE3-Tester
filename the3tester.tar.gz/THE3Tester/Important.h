int Important (int n, int**& edgeList, double*& scores);
